#ifndef _COMMON_H
#define _COMMON_H

#define MAX_CHAR_LENGTH 256
#define FLN 256

#define LARGE 100000
#define MAX 100000

#define NUM_INTER 50

#define PI 3.14159265

#endif
