#!/bin/sh

EXE=/Users/cjknight/Documents/Catalyst/Postdocs/Yasi/ChemNetworks/src/ChemNetworks-2.2.exe

${EXE} cn.inp lmp_save.xyz -new

#${EXE} cn.inp water1.xyz -new
