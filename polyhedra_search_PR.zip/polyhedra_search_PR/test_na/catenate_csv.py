import sys
import numpy as np
#from dump import dump
#from scipy.optimize import curve_fit
#import matplotlib.pyplot as plt
#from matplotlib.ticker import MaxNLocator 
#plt.style.use('classic')
#import plotly.plotly as py
#import plotly.tools as tls
import os, sys
import pandas as pd

print ("molecule_name, start_snap, end_snap, deltaT")
print ("eg. WATER/OCTA_OH, 0, 10000, 2")


#mole_name = sys.argv[1]
#mole_name2 = sys.argv[5]
#mole_name3 =sys.argv[6]
n = 7448 
time_b = int(sys.argv[1])  #0
time_e = int(sys.argv[2])  #10000
delta_t = int(sys.argv[3]) #1
t= time_b
amsum0 = []
amsum1 = []
with open('polys_polyhedra.csv','w') as xyz:
    while t <= time_e:
        print(t)
        with open('water_napolyhedra_final' + str(t) + '.input.Polys') as gro:
            for i, line in enumerate(gro):
                xyz.write(str((line.split()[0])+''))
                xyz.write(str((line.split()[1])+''))
                xyz.write(str((line.split()[2])+''))
                xyz.write(str((line.split()[3])+''))
                xyz.write(str((line.split()[4])+''))
                xyz.write(str((line.split()[5])+''))
                xyz.write(str((line.split()[6])+'\n'))
        t += delta_t
#hist1 = []
#bins1 = []
#num_bins = 20)
#hist,bins,n = plt.hist(amsum, num_bins, facecolor='blue', alpha=0.5, density = True)
#for i in xrange(0,len(hist)):
    #hist1.append(hist[i])
    #bins1.append(bins[i])



#combined_csv.to_csv( "polyhedra_accounting_distances.csv", index=False, encoding='utf-8-sig')
#plt.savefig('amsum_slab_a.pdf', bbox_inches='tight', ppi=1200)
#np.savetxt('polyhedra_accounting_distances.csv', amsum0)#np.column_stack((amsum0, amsum1)),('%.18e %.18e'))
#np.savetxt('hist_slab_a.csv',np.column_stack((hist1, bins1)))

























	
	
	
	


 


	
	









#sum_rows = np.sum(adjMatrix , axis=1)


	

   

#np.savetxt('amsum.csv',amsum)




















### PLOTTING
#NUM = len(Time)
#conv_step = 50
#conv_pont = NUM/conv_step

#sum_step_300K = []
#for i in xrange(conv_pont):
    
    #sum_step_300K.append((i*conv_step, np.mean(SurfTen_300K[:i*conv_step])/20.))
    

#sum_step_300K = np.array(sum_step_300K)

#plt.plot(sum_step_300K[:, 0], sum_step_300K[:, 1], label='T=300K', color='green', linewidth=1.0)

#plt.legend(loc='lower right', fontsize=14)
#plt.xlabel(r'Time (ps)', fontsize=12)
#plt.ylabel(r'r (mN/m)', fontsize=12)
#plt.ylim(2, 23)
#plt.xlim(230, 350)
#plt.savefig('SurfTens_Converge_Temp300.pdf', bbox_inches='tight', ppi=1200)
